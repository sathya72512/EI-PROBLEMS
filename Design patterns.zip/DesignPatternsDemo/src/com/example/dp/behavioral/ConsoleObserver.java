package com.example.dp.behavioral;

public class ConsoleObserver implements TaskObserver {
    @Override
    public void notify(String message) {
        System.out.println("[OBSERVER] " + message);
    }
}
