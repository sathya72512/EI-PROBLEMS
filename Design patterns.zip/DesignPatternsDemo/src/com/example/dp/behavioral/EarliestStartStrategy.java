package com.example.dp.behavioral;

import java.util.*;

public class EarliestStartStrategy implements SortStrategy {
    @Override
    public List<StrategyTask> sort(List<StrategyTask> tasks) {
        List<StrategyTask> copy = new ArrayList<>(tasks);
        copy.sort(Comparator.comparingInt(t -> t.start));
        return copy;
    }
}
