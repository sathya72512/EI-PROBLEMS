package com.example.dp.behavioral;

import java.util.*;

public class HighestPriorityStrategy implements SortStrategy {
    @Override
    public List<StrategyTask> sort(List<StrategyTask> tasks) {
        List<StrategyTask> copy = new ArrayList<>(tasks);
        copy.sort(Comparator.comparingInt(t -> t.priority));
        return copy;
    }
}
