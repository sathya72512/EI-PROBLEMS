package com.example.dp.behavioral;

public class ObserverDemo {
    public static void main(String[] args) {
        TaskSubject subject = new TaskSubject();
        subject.addObserver(new ConsoleObserver());

        subject.addTask(new Task("Morning Exercise", 7*60, 8*60)); // 07:00-08:00
        subject.addTask(new Task("Team Meeting", 9*60, 10*60));   // 09:00-10:00
        // Overlapping task (09:30-10:30)
        subject.addTask(new Task("Training", 9*60 + 30, 10*60 + 30));
    }
}
