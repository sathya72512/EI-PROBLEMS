package com.example.dp.behavioral;

import java.util.List;

public interface SortStrategy {
    List<StrategyTask> sort(List<StrategyTask> tasks);
}
