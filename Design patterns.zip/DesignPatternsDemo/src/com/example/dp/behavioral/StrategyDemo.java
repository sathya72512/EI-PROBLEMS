package com.example.dp.behavioral;

import java.util.*;

public class StrategyDemo {
    public static void main(String[] args) {
        List<StrategyTask> list = Arrays.asList(
            new StrategyTask("A", 9*60, 2),
            new StrategyTask("B", 7*60, 3),
            new StrategyTask("C", 8*60, 1)
        );

        SortStrategy s1 = new EarliestStartStrategy();
        System.out.println("By earliest start: " + s1.sort(list));

        SortStrategy s2 = new HighestPriorityStrategy();
        System.out.println("By highest priority: " + s2.sort(list));
    }
}
