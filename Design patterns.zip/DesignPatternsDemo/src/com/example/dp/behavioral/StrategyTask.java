package com.example.dp.behavioral;

public class StrategyTask {
    public String name;
    public int start;
    public int priority; // lower number = higher priority

    public StrategyTask(String n, int s, int p) {
        name = n; start = s; priority = p;
    }

    @Override
    public String toString() {
        return name + " (start=" + start + ", priority=" + priority + ")";
    }
}
