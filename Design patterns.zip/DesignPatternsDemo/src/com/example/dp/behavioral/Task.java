package com.example.dp.behavioral;

public class Task {
    public String name;
    public int start; // minutes from midnight
    public int end;

    public Task(String name, int start, int end) {
        this.name = name; this.start = start; this.end = end;
    }

    @Override
    public String toString() {
        return name + " [" + start + "-" + end + "]";
    }
}
