package com.example.dp.behavioral;

public interface TaskObserver {
    void notify(String message);
}
