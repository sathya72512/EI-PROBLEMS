package com.example.dp.behavioral;

import java.util.*;

public class TaskSubject {
    private List<Task> tasks = new ArrayList<>();
    private List<TaskObserver> observers = new ArrayList<>();

    public void addObserver(TaskObserver o) { observers.add(o); }

    public void addTask(Task t) {
        for (Task ex : tasks) {
            // overlap check
            if (!(t.end <= ex.start || t.start >= ex.end)) {
                notifyObservers("Conflict: " + t + " conflicts with " + ex);
            }
        }
        tasks.add(t);
        notifyObservers("Task added: " + t);
    }

    private void notifyObservers(String msg) {
        for (TaskObserver o : observers) o.notify(msg);
    }
}
