package com.example.dp.creational;

public class ExerciseTask implements Task {
    private String name;
    public ExerciseTask(String name) { this.name = name; }
    @Override
    public void execute() { System.out.println("Exercise: " + name); }
    @Override
    public String getName() { return name; }
}
