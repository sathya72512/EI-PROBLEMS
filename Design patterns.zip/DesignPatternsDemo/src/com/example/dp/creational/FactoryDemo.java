package com.example.dp.creational;

public class FactoryDemo {
    public static void main(String[] args) {
        Task t1 = TaskFactory.createTask(TaskFactory.Type.EXERCISE, "Morning Run");
        Task t2 = TaskFactory.createTask(TaskFactory.Type.MEETING, "Team Standup");
        t1.execute();
        t2.execute();
    }
}
