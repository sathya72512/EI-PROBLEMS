package com.example.dp.creational;

public class MeetingTask implements Task {
    private String name;
    public MeetingTask(String name) { this.name = name; }
    @Override
    public void execute() { System.out.println("Meeting: " + name); }
    @Override
    public String getName() { return name; }
}
