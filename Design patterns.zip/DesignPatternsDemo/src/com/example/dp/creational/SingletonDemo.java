package com.example.dp.creational;

public class SingletonDemo {
    public static void main(String[] args) {
        Logger l1 = Logger.getInstance();
        Logger l2 = Logger.getInstance();
        l1.log("Starting Singleton demo");
        System.out.println("Same instance? " + (l1 == l2));
    }
}
