package com.example.dp.creational;

public interface Task {
    void execute();
    String getName();
}
