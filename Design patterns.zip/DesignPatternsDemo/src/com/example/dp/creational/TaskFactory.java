package com.example.dp.creational;

public class TaskFactory {
    public enum Type { EXERCISE, MEETING }

    public static Task createTask(Type type, String name) {
        switch (type) {
            case EXERCISE: return new ExerciseTask(name);
            case MEETING: return new MeetingTask(name);
            default: throw new IllegalArgumentException("Unknown type");
        }
    }
}
