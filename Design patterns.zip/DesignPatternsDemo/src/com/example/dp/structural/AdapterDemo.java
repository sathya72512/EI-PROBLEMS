package com.example.dp.structural;

public class AdapterDemo {
    public static void main(String[] args) {
        LegacyPrinter lp = new LegacyPrinter();
        NewPrinter np = new PrinterAdapter(lp);

        Document doc = new Document("Hello from Adapter!");
        np.printDocument(doc);
    }
}
