package com.example.dp.structural;

public class BaseNotifier implements Notifier {
    @Override
    public void send(String message) {
        System.out.println("Send basic notification: " + message);
    }
}
