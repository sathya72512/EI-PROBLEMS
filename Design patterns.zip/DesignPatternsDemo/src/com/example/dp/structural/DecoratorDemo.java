package com.example.dp.structural;

public class DecoratorDemo {
    public static void main(String[] args) {
        Notifier notifier = new SMSDecorator(new EmailDecorator(new BaseNotifier()));
        notifier.send("Task due at 09:00");
    }
}
