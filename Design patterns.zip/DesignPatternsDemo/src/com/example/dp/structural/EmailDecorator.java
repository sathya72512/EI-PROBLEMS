package com.example.dp.structural;

public class EmailDecorator extends NotifierDecorator {
    public EmailDecorator(Notifier n) { super(n); }
    @Override
    public void send(String message) {
        super.send(message);
        System.out.println("Also sending EMAIL: " + message);
    }
}
