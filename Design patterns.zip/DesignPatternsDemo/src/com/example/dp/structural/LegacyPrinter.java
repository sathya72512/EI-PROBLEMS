package com.example.dp.structural;

public class LegacyPrinter {
    public void print(String text) {
        System.out.println("Legacy printing: " + text);
    }
}
