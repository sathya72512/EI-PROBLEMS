package com.example.dp.structural;

public interface NewPrinter {
    void printDocument(Document doc);
}
