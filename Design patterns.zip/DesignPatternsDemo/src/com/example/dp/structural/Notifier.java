package com.example.dp.structural;

public interface Notifier {
    void send(String message);
}
