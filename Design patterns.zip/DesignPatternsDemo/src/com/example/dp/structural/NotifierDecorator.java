package com.example.dp.structural;

public abstract class NotifierDecorator implements Notifier {
    protected Notifier wrappee;
    public NotifierDecorator(Notifier n) {
        this.wrappee = n;
    }
    @Override
    public void send(String message) {
        wrappee.send(message);
    }
}
