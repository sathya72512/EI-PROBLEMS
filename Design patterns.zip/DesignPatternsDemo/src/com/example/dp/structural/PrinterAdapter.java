package com.example.dp.structural;

public class PrinterAdapter implements NewPrinter {
    private LegacyPrinter legacy;
    public PrinterAdapter(LegacyPrinter legacy) {
        this.legacy = legacy;
    }
    @Override
    public void printDocument(Document doc) {
        legacy.print(doc.getContent());
    }
}
