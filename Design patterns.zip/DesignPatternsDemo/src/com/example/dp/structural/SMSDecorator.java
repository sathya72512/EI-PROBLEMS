package com.example.dp.structural;

public class SMSDecorator extends NotifierDecorator {
    public SMSDecorator(Notifier n) { super(n); }
    @Override
    public void send(String message) {
        super.send(message);
        System.out.println("Also sending SMS: " + message);
    }
}
