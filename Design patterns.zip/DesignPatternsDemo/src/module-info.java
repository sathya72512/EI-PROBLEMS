/**
 * 
 */
/**
 * 
 */
module DesignPatternsDemo {
}